import MainShowcase from "../sections/MainShowcase";
import SideNav from "../components/socials/SideNav";
import About from "../sections/about/About";
import Portfolio from "../sections/Portfolio";
import Contact from "../sections/Contact";
import Footer from "../sections/Footer";

const LandingPage = () => {
  return (
    <div>
      <MainShowcase />
      <SideNav />
      <About />
      <Portfolio />
      <Contact />
      <Footer />
    </div>
  );
};

export default LandingPage;
