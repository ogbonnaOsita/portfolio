/* eslint-disable react/no-unescaped-entities */
import { useRef } from "react";
import AwesomeBtn from "../components/awesomeBtn/AwesomeBtn";

const Contact = () => {
  const contactRef = useRef(null);
  const mouseMoveHandler = (e) => {
    const submitBtn = document.querySelector(".submit-btn");
    var rect = submitBtn.getBoundingClientRect();

    const x = e.clientX - rect.x;
    const y = e.clientY - rect.y;

    contactRef.current.style.setProperty("--x", x + "px");
    contactRef.current.style.setProperty("--y", y + "px");
  };
  return (
    <div className="bg-brownAccent dark:bg-[#1a1a1a] py-[7rem]">
      <div className="max-w-[90%] md:max-w-[80%] mx-auto ">
        <div>
          <h2
            className={` mb-10 md:mb-[5rem] relative text-[3.5vw] font-extrabold text-secondary dark:text-[#fff] text-center uppercase stroke-[1rem] z-20 bg-clip-text
        before:content-['get_in_touch'] before:text-[8vw] before:absolute  before:top-[50%] before:left-[50%] before:-translate-x-[50%] 
        before:-translate-y-[50%] before:text-center before:text-[#000] before:-z-[1] before:w-full before:opacity-30`}
          >
            Get in{" "}
            <span className={`text-primary dark:text-darkPrimary`}>touch</span>
          </h2>
        </div>
        <section className="text-secondary dark:text-gray-200 body-font relative">
          <div className="container px-5 mx-auto">
            <div className="flex flex-col text-center w-full mb-12">
              <p className="lg:w-2/3 mx-auto leading-relaxed text-base">
                Feel free to reach out to me, I'm always open to discussing
                creative ideas, and the opportunity to join your team.
              </p>
            </div>
            <div className="lg:w-full md:w-full mx-auto">
              <div className="flex flex-wrap -m-2">
                <div className="p-2 w-full md:w-1/2">
                  <div className="relative">
                    <input
                      type="text"
                      id="name"
                      name="name"
                      placeholder="Your Name"
                      className="w-full dark:bg-[#3b3b3b] bg-white dark:bg-opacity-50 rounded  dark:focus:border-[#4bffa5] dark:focus:bg-[#d7d7d9] dark:focus:text-[#333] dark:placeholder:text-gray-200 dark:focus:placeholder:text-secondary focus:ring-2 focus:ring-[#222] text-base outline-none dark:text-gray-200 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out"
                    />
                  </div>
                </div>
                <div className="p-2 w-full md:w-1/2">
                  <div className="relative">
                    <input
                      type="email"
                      id="email"
                      name="email"
                      placeholder="Your Email"
                      className="w-full dark:bg-[#3b3b3b] bg-white dark:bg-opacity-50 rounded  dark:focus:border-[#4bffa5] dark:focus:bg-[#d7d7d9] dark:focus:text-[#333] dark:placeholder:text-gray-200 dark:focus:placeholder:text-secondary focus:ring-2 focus:ring-[#222] text-base outline-none dark:text-gray-200 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out"
                    />
                  </div>
                </div>
                <div className="p-2 w-full">
                  <div className="relative">
                    <input
                      type="text"
                      id="subject"
                      name="subject"
                      placeholder="Your Subject"
                      className="w-full dark:bg-[#3b3b3b] bg-white dark:bg-opacity-50 rounded  dark:focus:border-[#4bffa5] dark:focus:bg-[#d7d7d9] dark:focus:text-[#333] dark:placeholder:text-gray-200 dark:focus:placeholder:text-secondary focus:ring-2 focus:ring-[#222] text-base outline-none dark:text-gray-200 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out"
                    />
                  </div>
                </div>
                <div className="p-2 w-full">
                  <div className="relative">
                    <textarea
                      id="message"
                      name="message"
                      placeholder="Your Message"
                      className="w-full dark:bg-[#3b3b3b]  bg-white dark:bg-opacity-50 rounded  dark:focus:border-[#4bffa5] dark:focus:bg-[#d7d7d9] dark:focus:text-[#333] dark:placeholder:text-gray-200 dark:focus:placeholder:text-secondary focus:ring-2 focus:ring-[#222] h-32 text-base outline-dark:none dark:text-gray-200 py-1 px-3 resize-none leading-6 transition-colors duration-200 ease-in-out"
                    ></textarea>
                  </div>
                </div>
                <div className="p-2 w-full text-center">
                  <a
                    ref={contactRef}
                    onMouseMoveCapture={(e) => mouseMoveHandler(e)}
                    href="#"
                    className="text-secondary hover:text-white dark:hover:text-[#333] dark:text-darkPrimary px-5 py-2 border-2 border-secondary dark:border-darkPrimary rounded-md submit-btn before:bg-secondary dark:before:bg-darkPrimary"
                  >
                    <span>Submit</span>
                  </a>
                  {/* <AwesomeBtn text="Hello" /> */}
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default Contact;
