import { useRef } from "react";

const Navbar = () => {
  const navBtn = useRef(null);

  return (
    <div>
      <div className="flex justify-between py-6">
        <div className="left nav-logo">
          <h2>
            <span>Osita </span>Ogbonna
          </h2>
        </div>
        <div className="right">
          <ul className="flex gap-5 items-center">
            <li>
              <a href="#" ref={navBtn} className="nav-links">
                <span>Home</span>
              </a>
            </li>
            <li>
              <a href="#" className="nav-links">
                Projects
              </a>
            </li>
            <li>
              <a href="#" className="nav-links">
                Contact Me
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Navbar;
